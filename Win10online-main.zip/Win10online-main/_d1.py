﻿# -*- coding: utf-8 -*-
import io, re
# desk.js 中重启相关
t = io.open(r"D:\Win10online-main\windows\pages\desk.js", encoding='utf-8').read()
idx = 0
for m in re.finditer(r'重启', t):
    s = max(0, m.start()-200); e = min(len(t), m.end()+300)
    print("=== desk.js 片段 @", m.start(), "===")
    print(t[s:e])
    print()
