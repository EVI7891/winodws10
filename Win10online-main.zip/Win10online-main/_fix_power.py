﻿# -*- coding: utf-8 -*-
import io, os, shutil

pages = r"D:\Win10online-main\windows\pages"
backup_dir = os.path.join(pages, "_backup")
os.makedirs(backup_dir, exist_ok=True)

# ---------- 1) 备份 ----------
for fn in ["poweroff.html", "black.html"]:
    src = os.path.join(pages, fn)
    dst = os.path.join(backup_dir, fn + ".original")
    if os.path.exists(src):
        shutil.copy2(src, dst)
        print("backup ->", dst)

# ---------- 2) 修复 poweroff.html ----------
p_off = os.path.join(pages, "poweroff.html")
html = io.open(p_off, encoding='utf-8').read()

old_script = """    if($_GET('mode')=='restart'){
        document.querySelector('.title').innerText='正在重启';
        setTimeout(() => {
        setTimeout(() => {
            location.href='black.html'
        }, 5000);
        }else{"""
new_script = """    if($_GET('mode')=='restart'){
        document.querySelector('.title').innerText='正在重启';
        setTimeout(function(){
            location.href='black.html?mode=restart';
        }, 5000);
    } else {
        document.querySelector('.title').innerText='正在关机';
        setTimeout(function(){
            location.href='black.html';
        }, 5000);
    }"""
assert old_script in html, "poweroff.html 脚本锚点未命中"
html = html.replace(old_script, new_script)
io.open(p_off, 'w', encoding='utf-8').write(html)
print("poweroff.html 已修复")

# ---------- 3) 修复 black.html：重启时黑屏后自动开机 ----------
p_black = os.path.join(pages, "black.html")
black = io.open(p_black, encoding='utf-8').read()
if '$_GET' not in black:
    black = """<body style="background:#000;cursor:none;margin:0;">
</body>
<script src="../urlreader.js"></script>
<script>
    if($_GET('mode')=='restart'){
        setTimeout(function(){
            location.href='poweron.html';
        }, 3000);
    }
</script>
"""
    io.open(p_black, 'w', encoding='utf-8').write(black)
    print("black.html 已补全重启脚本")
else:
    print("black.html 已有脚本，跳过")
