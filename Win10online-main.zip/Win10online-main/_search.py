﻿# -*- coding: utf-8 -*-
import io, os
root = r"D:\Win10online-main"
hits = []
for dirpath, dirnames, filenames in os.walk(root):
    for fn in filenames:
        if fn.endswith(('.html', '.js', '.css')):
            p = os.path.join(dirpath, fn)
            try:
                txt = io.open(p, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            for kw in ['重启', 'reboot', 'restart', 'shutdown', 'poweroff', 'poweron']:
                if kw in txt.lower():
                    hits.append((p, kw))
                    break
for p, kw in hits:
    print(kw, '->', p)
