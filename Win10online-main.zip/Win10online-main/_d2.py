﻿# -*- coding: utf-8 -*-
import io, os
root = r"D:\Win10online-main"
for dirpath, dirnames, filenames in os.walk(root):
    for fn in filenames:
        if fn.endswith(('.html', '.js')):
            p = os.path.join(dirpath, fn)
            try:
                txt = io.open(p, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            if 'black.html' in txt:
                for i, line in enumerate(txt.split('\n'), 1):
                    if 'black.html' in line:
                        print(p, 'line', i, ':', line.strip()[:120])
